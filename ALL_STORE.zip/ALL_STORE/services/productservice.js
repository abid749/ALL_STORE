import productsData from '../data/products.json';

export function getAllProducts() {
  return productsData;
}

export function getProductById(id) {
  return productsData.find(p => p.id === id);
}

// Tambah, update, delete produk bisa ditambah jika perlu