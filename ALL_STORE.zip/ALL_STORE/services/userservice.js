import usersData from '../data/users.json';

export function getUserById(id) {
  return usersData.find(u => u.id === id);
}

export function getUserByEmail(email) {
  return usersData.find(u => u.email === email);
}

export function addProductToUser(userId, productId) {
  const user = usersData.find(u => u.id === userId);
  if (!user) throw new Error('User not found');
  if (!user.products.includes(productId)) {
    user.products.push(productId);
  }
  return user;
}

export function unlockPortForUser(userId, port) {
  const user = usersData.find(u => u.id === userId);
  if (!user) throw new Error('User not found');
  if (!user.unlockedPorts.includes(port)) {
    user.unlockedPorts.push(port);
  }
  return user;
}