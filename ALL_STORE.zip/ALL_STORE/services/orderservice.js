import ordersData from '../data/orders.json';

export function getOrdersByUser(userId) {
  return ordersData.filter(o => o.userId === userId);
}

export function createOrder(userId, productId, amount, paymentMethod) {
  const newOrder = {
    id: 'order-' + (ordersData.length + 1).toString().padStart(3, '0'),
    userId,
    productId,
    status: 'pending', // awalnya pending
    paymentMethod,
    amount,
    date: new Date().toISOString()
  };
  ordersData.push(newOrder);
  return newOrder;
}

export function updateOrderStatus(orderId, status) {
  const order = ordersData.find(o => o.id === orderId);
  if (!order) throw new Error('Order not found');
  order.status = status;
  return order;
}