import React from 'react';

export default function DomainList({ domains }) {
  if (!domains.length) return <p>No domains purchased.</p>;

  return (
    <ul>
      {domains.map(domain => (
        <li key={domain.id}>
          {domain.name} - Status: {domain.status}
        </li>
      ))}
    </ul>
  );
}