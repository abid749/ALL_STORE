import React from 'react';

export default function PricingTable({ products, onSelect }) {
  return (
    <div className="pricing-table">
      {products.map(product => (
        <div key={product.id} className="product-card" onClick={() => onSelect(product.id)}>
          <h3>{product.name}</h3>
          <p>{product.description}</p>
          <p>Price: Rp {product.price.toLocaleString()}</p>
        </div>
      ))}

      <style jsx>{`
        .pricing-table { display: flex; gap: 20px; flex-wrap: wrap; }
        .product-card { border: 1px solid #ccc; padding: 1rem; border-radius: 8px; cursor: pointer; flex: 1 1 200px; }
        .product-card:hover { box-shadow: 0 0 10px rgba(0,0,0,0.2); }
      `}</style>
    </div>
  );
}