import React from 'react';

export default function ServerList({ servers }) {
  if (!servers.length) return <p>No servers found.</p>;

  return (
    <table>
      <thead>
        <tr>
          <th>Server ID</th>
          <th>Product</th>
          <th>Status</th>
          <th>Port</th>
        </tr>
      </thead>
      <tbody>
        {servers.map(server => (
          <tr key={server.id}>
            <td>{server.id}</td>
            <td>{server.productName}</td>
            <td>{server.status}</td>
            <td>{server.port}</td>
          </tr>
        ))}
      </tbody>

      <style jsx>{`
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ccc; padding: 0.5rem; text-align: left; }
        th { background: #eee; }
      `}</style>
    </table>
  );
}