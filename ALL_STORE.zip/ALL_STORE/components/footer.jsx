import React from 'react';

export default function Footer() {
  return (
    <footer>
      <p>© 2025 AllStore Hosting. All rights reserved.</p>
      <style jsx>{`
        footer { padding: 1rem; text-align: center; background: #222; color: #ccc; position: fixed; bottom: 0; width: 100%; }
      `}</style>
    </footer>
  );
}