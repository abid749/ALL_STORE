import React from 'react';
import ServerList from './ServerList';
import DomainList from './DomainList';

export default function UserDashboard({ user, servers, domains }) {
  return (
    <div>
      <h2>Welcome, {user.name}</h2>
      <section>
        <h3>Your Servers</h3>
        <ServerList servers={servers} />
      </section>
      <section>
        <h3>Your Domains</h3>
        <DomainList domains={domains} />
      </section>
    </div>
  );
}