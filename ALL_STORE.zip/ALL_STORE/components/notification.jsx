import React from 'react';

export default function Notification({ message, type = 'info', onClose }) {
  if (!message) return null;

  return (
    <div className={`notification ${type}`}>
      <span>{message}</span>
      <button onClick={onClose}>X</button>

      <style jsx>{`
        .notification {
          padding: 1rem;
          margin: 1rem 0;
          border-radius: 5px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-weight: bold;
        }
        .info { background: #cce5ff; color: #004085; }
        .success { background: #d4edda; color: #155724; }
        .error { background: #f8d7da; color: #721c24; }
        button {
          background: transparent;
          border: none;
          font-size: 1.2rem;
          cursor: pointer;
          color: inherit;
        }
      `}</style>
    </div>
  );
}