// Contoh fungsi umum yang sering dipakai

// Format tanggal ke string readable
export function formatDate(dateString) {
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
}

// Cek apakah user punya role tertentu
export function hasRole(user, role) {
  if (!user || !user.role) return false;
  return user.role === role;
}

// Fungsi delay asinkron (untuk simulasi loading)
export function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}