import { useState } from 'react';
import { processPayment } from '../services/orderService';
import { getCurrentUser } from '../services/authService';

export default function PaymentPage() {
  const [orderId, setOrderId] = useState('');
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handlePayment = async () => {
    if (!orderId || !amount) {
      setMessage('Please fill all fields');
      return;
    }
    setLoading(true);
    const user = await getCurrentUser();
    if (!user) {
      setMessage('Please login first');
      setLoading(false);
      return;
    }
    const result = await processPayment(user.id, orderId, amount);
    setLoading(false);
    if (result.success) {
      setMessage('Payment processed successfully!');
    } else {
      setMessage(result.message || 'Payment failed');
    }
  };

  return (
    <div className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Payment</h1>
      <input
        type="text"
        placeholder="Order ID"
        value={orderId}
        onChange={(e) => setOrderId(e.target.value)}
        className="border p-2 rounded w-full mb-4"
      />
      <input
        type="number"
        placeholder="Amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        className="border p-2 rounded w-full mb-4"
      />
      <button
        onClick={handlePayment}
        disabled={loading}
        className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
      >
        {loading ? 'Processing...' : 'Pay'}
      </button>
      {message && <p className="mt-4 text-red-600">{message}</p>}
    </div>
  );
}