import { useEffect, useState } from 'react';
import { getUserData } from '../services/userService';
import { getOrdersByUser } from '../services/orderService';
import UserDashboard from '../components/UserDashboard';

export default function DashboardPage() {
  const [user, setUser] = useState(null);
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const userData = await getUserData();
      setUser(userData);
      if (userData) {
        const userOrders = await getOrdersByUser(userData.email);
        setOrders(userOrders);
      }
    };
    fetchData();
  }, []);

  if (!user) {
    return (
      <div className="text-center py-20">
        <p className="text-gray-600">Loading dashboard...</p>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
      <UserDashboard user={user} orders={orders} />
    </div>
  );
}