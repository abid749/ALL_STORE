import { useState, useEffect } from 'react';
import { getCurrentUser, updateUserProfile } from '../services/authService';

export default function ProfilePage() {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    async function fetchUser() {
      const currentUser = await getCurrentUser();
      if (currentUser) {
        setUser(currentUser);
        setEmail(currentUser.email);
        setName(currentUser.name || '');
      }
    }
    fetchUser();
  }, []);

  const handleUpdate = async () => {
    if (!email) return setMessage('Email cannot be empty');
    const result = await updateUserProfile(user.id, { email, name });
    if (result.success) {
      setMessage('Profile updated successfully!');
      setUser(result.user);
    } else {
      setMessage(result.message || 'Failed to update profile');
    }
  };

  if (!user) return <p>Loading...</p>;

  return (
    <div className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Edit Profile</h1>
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="border p-2 rounded w-full mb-4"
      />
      <input
        type="text"
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="border p-2 rounded w-full mb-4"
      />
      <button
        onClick={handleUpdate}
        className="bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700"
      >
        Update Profile
      </button>
      {message && <p className="mt-4 text-green-700">{message}</p>}
    </div>
  );
}