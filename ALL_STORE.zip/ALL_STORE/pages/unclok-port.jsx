import { useState, useEffect } from 'react';
import { getUser, unlockPort } from '../services/portService';
import { getCurrentUser } from '../services/authService';

export default function UnlockPortPage() {
  const [user, setUser] = useState(null);
  const [ports, setPorts] = useState([]);
  const [portToUnlock, setPortToUnlock] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchUser = async () => {
      const currentUser = await getCurrentUser();
      setUser(currentUser);

      if (currentUser) {
        const userPorts = await getUser(currentUser.id);
        setPorts(userPorts);
      }
    };
    fetchUser();
  }, []);

  const handleUnlock = async () => {
    if (!portToUnlock) return setMessage('Please enter a port to unlock');

    const result = await unlockPort(user.id, portToUnlock);
    if (result.success) {
      setMessage('Port unlocked successfully!');
      setPorts(await getUser(user.id));  // Refresh ports list
      setPortToUnlock('');
    } else {
      setMessage(result.message || 'Failed to unlock port');
    }
  };

  if (!user) return <p>Loading...</p>;

  return (
    <div className="max-w-xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Unlock Port</h1>
      <p className="mb-4">User: {user.email} (Role: {user.role})</p>

      <div className="mb-4">
        <label className="block mb-2 font-semibold">Your Unlocked Ports:</label>
        <ul className="list-disc pl-5">
          {ports.length > 0 ? (
            ports.map((port) => <li key={port}>{port}</li>)
          ) : (
            <li>No ports unlocked yet.</li>
          )}
        </ul>
      </div>

      {(user.role === 'admin' || user.role === 'owner') && (
        <>
          <input
            type="text"
            placeholder="Enter port to unlock"
            value={portToUnlock}
            onChange={(e) => setPortToUnlock(e.target.value)}
            className="border p-2 rounded w-full mb-4"
          />
          <button
            onClick={handleUnlock}
            className="bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700"
          >
            Unlock Port
          </button>
        </>
      )}

      {message && <p className="mt-4 text-red-600">{message}</p>}
    </div>
  );
}